package com.example.flightsimapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.server_item.view.*

//class ServerListAdapter(val serverlist: List<Server> , var clickListener: OnServerItemClickListener):RecyclerView.Adapter<ServerListAdapter.ServerListViewHolder>() {
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServerListViewHolder {
//        val itemView = LayoutInflater.from((parent.context)).inflate(R.layout.server_item,parent,false)
//        return ServerListViewHolder(itemView)
//    }
//
//    override fun getItemCount(): Int {
//        return serverlist.size
//    }
//
//    override fun onBindViewHolder(holder: ServerListViewHolder, position: Int) {
//        holder.initialize(serverlist.get(position),clickListener)
////        val currenItem = serverlist[position]
////        holder.serveraddreess.text =  currenItem.address
//    }
//    class ServerListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
//        val serveraddreess :TextView = itemView.textView
//        fun initialize(item: Server,action:OnServerItemClickListener){
//            serveraddreess.text = item.address
//            itemView.setOnClickListener {
//                action.OnItemClick(item,adapterPosition)
//            }
//        }
//    }
//
//}



class ServerListAdapter internal constructor(context: Context,var clickListener: OnServerItemClickListener) : RecyclerView.Adapter<ServerListAdapter.ServerListViewHolder>() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var servers = emptyList<ServerEntity>() // Cached copy of words

    inner class ServerListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val serverItemView: TextView = itemView.findViewById(R.id.textView)
        fun initialize(item: ServerEntity,action:OnServerItemClickListener){
            serverItemView.text = item.server_url
            itemView.setOnClickListener {
                action.OnItemClick(item,adapterPosition)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServerListViewHolder {
        val itemView = inflater.inflate(R.layout.server_item, parent, false)
        return ServerListViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ServerListAdapter.ServerListViewHolder, position: Int) {
        holder.initialize(servers.get(position),clickListener)
//        val current = servers[position]
//        holder.serverItemView.text = current.server_url
    }

    internal fun setServers(words: List<ServerEntity>) {
        this.servers = words
        notifyDataSetChanged()
    }

    override fun getItemCount() = servers.size
}
interface OnServerItemClickListener{
    fun OnItemClick(item : ServerEntity,position: Int)
}