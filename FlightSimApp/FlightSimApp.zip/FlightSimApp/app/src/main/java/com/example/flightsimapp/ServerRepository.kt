package com.example.flightsimapp

import androidx.lifecycle.LiveData

class ServerRepository(private val servaerDao: Servaer_DAO) {

    // Room executes all queries on a separate thread.
    // Observed LiveData will notify the observer when the data has changed.
    val allWords: LiveData<List<ServerEntity>> = servaerDao.getAlphabetizedWords()

    suspend fun insert(serverEntity: ServerEntity) {
        servaerDao.insert(serverEntity)
    }
    suspend fun deleteServer(serverId:Int) {
        servaerDao.deleteServer(serverId)
    }
}